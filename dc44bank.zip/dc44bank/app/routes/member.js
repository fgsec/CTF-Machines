var express = require('express');
var router = express.Router();
var User = require('../models/user');
var mongoose = require('mongoose');
var userdata;

/* Get member page. */
router.get('/', function(req, res, next) {
  if(req.cookies.logged){
    var uid = req.cookies.logged;
    var query = User.findOne({ '_id' : uid });
    query.select('name email money card image_url');
    query.exec(function (err, user) {
    if (err) return handleError(err);
      userdata=user;
      res.render('member', { userdata: user, title: 'member', action:'MAIN' });
    });
  } else {
    res.redirect('/login');
  }
});
router.get('/withdraw', function(req, res, next) {
  res.render('member', { action: 'WITHDRAW', userdata: userdata, title: 'Withdraw' });
});
router.get('/deposit', function(req, res, next) {
  res.render('member', { action: 'DEPOSIT', userdata: userdata, title: 'Deposit' });
});
router.get('/logout', function(req, res, next) {
  res.clearCookie("logged");
  res.redirect('/login');
});
router.get('/transact', function(req, res, next) {
  res.send('it goes to get');
});
router.post('/transact', function(req, res, next) {

  console.log('transact working');
  var amount = req.body.amount;
  var card = req.body.card;
  var action = req.body.action;
  console.log(amount+' '+card+' '+action);

    if(action=='TRANSFER'){

      var card_destination = req.body.card_destination;
      var newAmount = parseInt(userdata.money) - parseInt(amount);
      // CHeck if user has money for transfer
      if(newAmount<0){res.redirect('/member'); return;}

      console.log("User has enough money");

      // Remove money from account
      var withdraw = User.updateOne(
      { 'card' : card },
      { $set: { 'money' : newAmount } }
      );
      withdraw.exec(function (err, result) {
      if (err) return handleError(err);

        // Add new value in account
        console.log("Removed money from account!");
        console.log("Making deposit to:" + card_destination)

        var query = User.findOne({'card':card_destination});
        //console.log(query);
        query.select('name card money');
        query.exec(function (err, user_destination) {
          if (err) return handleError(err);

          console.log("Inside Deposit Operation");
          //console.log(user_destination);

          var newAmount_destination = (parseInt(amount) + parseInt(user_destination.money)).toString();
          var deposit = User.updateOne(
          { 'card' : card_destination },
          { $set: { 'money' : newAmount_destination } }
          );
          deposit.exec(function (err, result) {
          if (err) return handleError(err);
            console.log(result);
          });

        });

      });
      
    };

    if(action=='DEPOSIT'){
      var newAmount = (parseInt(amount) + parseInt(userdata.money)).toString();
      var deposit = User.updateOne(
      { 'card' : card },
      { $set: { 'money' : newAmount } }
      );
      deposit.exec(function (err, result) {
      if (err) return handleError(err);
        console.log(result);
      });
    };
    if(action=='WITHDRAW'){
      var newAmount = parseInt(userdata.money) - parseInt(amount);
      if(newAmount<0){res.redirect('/member'); return;}
      var withdraw = User.updateOne(
      { 'card' : card },
      { $set: { 'money' : newAmount } }
      );
      withdraw.exec(function (err, result) {
      if (err) return handleError(err);
        console.log(result);
      });
    };

    res.redirect('/member');

});
module.exports = router;
