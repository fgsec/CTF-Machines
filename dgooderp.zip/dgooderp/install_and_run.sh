docker build --pull -t dgooderp .
docker image ls
docker run -d -p8001:8001 dgooderp