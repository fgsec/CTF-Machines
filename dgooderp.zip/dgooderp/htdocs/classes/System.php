<?php

class System {


	function load($f3) {

		if($f3->get("SESSION.auth")) {
			$f3->set('validation',$f3->get("SESSION.validation"));
			echo View::instance()->render('../pages/index_page.html');
		}
		else
			$f3->reroute("/login");
		
	}



}