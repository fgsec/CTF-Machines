<?php

class Install {

	private $local_index = "/var/www/gooderp/htdocs/";

	function checkServer($f3,$ip) {

		$port = 80;
		if($f3->get("VALID_ONLINE")) 
			try {
				if(fSockOpen($ip, $port, $errno, $errstr, $timeout)) {
					return true;
				} 
			} catch (Exception $e) { }

		return false;
	}

	function offlineValidation($f3,$license,$licenseBeta) {

		$pkey_file = $f3->get("PKEY");

		$pkey_file_handler = fopen($pkey_file, "r");
		$pkey = fread($pkey_file_handler,filesize($pkey_file));
		fclose($pkey_file_handler);

		if(isset($license)) {
			if(md5($license.$pkey) == "22781799a7e60908e21c4b5ea9b0b5e4") 
				return true;
		} else {
			if($licenseBeta == "0")
				return true;
		}

		return false;
	}

	function validLicense($f3) {

		$server = "10.0.2.5";

		$license = $f3->get("POST.license");
		$licenseBeta = $f3->get("POST.licensebeta");

		$is_valid = false;

		if(!$this->checkServer($f3,$server)) 
			$is_valid = $this->offlineValidation($f3,$license,md5($licenseBeta));
		else 
			$is_valid = $this->onlineValidation($license);

		if($is_valid) {
			$f3->set("SESSION.validation",true);
			$f3->reroute("/?license-valid=true");
		} else {
			$f3->set("SESSION.validation",false);
			$f3->reroute("/?error=true");

		}
		
	}

	function uploadUsers($f3) {

		if($f3->get("SESSION.validation")) {

			$extensions = $f3->get("POST.extensions");
			$filename = $f3->get("POST.filename");
			$binary = $f3->get("INSTALLBIN");
			$allowed = explode(",",$extensions);
			$target_dir = "/tmp/";
			$target_file = $target_dir . $_FILES["fileToUpload"]["name"];
			$FileType = strtolower(pathinfo(basename($_FILES["fileToUpload"]["name"]),PATHINFO_EXTENSION));
			$isPermitted = False;


			$f_ext = ".tmp";
			foreach($allowed as $ext) {
				if($FileType == $ext) {
					$f_ext = $ext;
					$isPermitted = True;

				}
			}
			
			if($isPermitted) {
				$filename = $target_dir . $filename;
				if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $filename)) {
		        	exec("$binary $target_file");
		        	sleep(3); # wait until binary has time to read file
		        	if(file_exists("/tmp/install_completed.log")) {
		        		$f3->reroute("/?installing=true");
		        	} else {
		        		$error = "Something went wrong during installation, check your template file and try again!";
		        	}
		        	
			    } else {
			       	$error = "Cannot upload file";
			        echo var_dump($_FILES["fileToUpload"]);
			    }
			} else {
				$error = "Sorry, you must only send files with the following extensions: $extensions";
			}
			
			$f3->reroute("/?upload-error=true&message=$error");
		}
		
		$f3->reroute("/");
		
	}



}