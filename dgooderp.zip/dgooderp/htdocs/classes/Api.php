<?php

class Api {

	public $classes_path = "classes";

	function getFunctions($file) {

		$rs = array();
	    $source = file_get_contents($file);
	    $lines = explode("\n",$source);
	    foreach($lines as $line) {
	    	if(strpos($line, 'function')) {
	    		$parts = explode(" ",$line);
	    		if(count($parts) == 3) {
	    			$name = $parts[1];
	    			array_push($rs,$name);
	    		}
	    	}

	    }

	    return $rs;
	}

	function getVariables($file) {
		$rs = array();
	    $source = file_get_contents($file);

	    $lines = explode("\n",$source);
	    foreach($lines as $line) {
	    	if(strpos($line, '$') && strpos($line, '=') && $line[2] == "$") {
	    		$name = explode("=",$line)[0];
	    		array_push($rs,$name);
	    	}

	    }
	    return $rs;
	}

	function getCode($file) { 
		$source = file_get_contents($file);
		return $source;
	}

	function listFolder($folder) {

		$files = scandir($folder);
		return $files;
	}

	function safeCheck($classes,$class) {
		foreach($classes as $allowed_class) {
			if("$class.php" == $allowed_class) {
				return True;
			}
		}
		return false;
	}

	function readClass($f3) {

		$classes_path = $this->classes_path;

		$class = $f3->get("PARAMS.class");
		$type = $f3->get("PARAMS.type");

		$classes = $this->listFolder($classes_path);

		if($this->safeCheck($classes,$class)) {

			if($type == "showFunctions") 
				$contents = $this->getFunctions("$classes_path/$class.php");
			if($type == "showVariables") 
				$contents = $this->getVariables("$classes_path/$class.php");
			if($type == "showCode") 
				$contents = $this->getCode("$classes_path/$class.php");

			$f3->set("class",$class);
			$f3->set("type",$type);
			$f3->set("contents",$contents);
			echo View::instance()->render('../pages/api_class_page.html');
		} else
			$f3->reroute("/api");
		
	}

	function load($f3) {

	
		$f3->set("classes",$this->listFolder($this->classes_path));
		echo View::instance()->render('../pages/api_page.html');



	}

}