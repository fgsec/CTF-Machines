<?php

class Login {

	function validInstallAccess($f3,$username,$password) {
		
		date_default_timezone_set('UTC');
		$day_access = str_split(md5((date("m") . date("y") + date("d"))),5)[0];
		if($username == "installaccount" && $password == "tempaccount@$day_access")
			return True;
		return False;

	}

	function validConfigurationAccount($f3,$username,$password) {
		// DEBUG INSTALL SERVICE
		//if($username == "admin" && $password == "admin") {
		//	return true;
		//}
		return false;
	}

	function load($f3) {
		echo View::instance()->render('../pages/login_page.html');
	}

	function valid($f3) {

		
		$username = $f3->get("POST.username");
		$password = $f3->get("POST.password");
		$error = $f3->get("PARAMS.error");

		if($this->validInstallAccess($f3,$username,$password) || $this->validConfigurationAccount($f3,$username,$password)) {
			$f3->set("SESSION.auth",$username);
			$f3->reroute("/");
		}

		$f3->reroute("/login?error=logon");
		
	}

	function logout($f3) {
		$f3->clear('SESSION');
		$f3->reroute("/");
	}


}