<?php

/*
	CTF Box created by @fgsec
	INSTALL SYSTEM FOR GOOD ERP
	Version 0.2
*/

$f3 = require('erp/lib/base.php');

$f3->set('FLAG','CTF-SSI{N1c3_w3b_sK1lls_b0000iiiii}');

$f3->set('VALID_ONLINE',false);
$f3->set('INSTALLBIN',"/var/www/gooderp/installgooderp");
$f3->set('PKEY','/var/www/gooderp/gooderp_pkey.txt');
$f3->set('CACHE','folder=/tmp/');
$f3->set('DEBUG',1);

$f3->config('config.ini');

new Session();

# Auto Class load

spl_autoload_register( function ($class_name) {
    $CLASSES_DIR = __DIR__ . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR;
    $file = $CLASSES_DIR . $class_name . '.php';
    if( file_exists( $file ) ) include $file;
} );

# Route Definition

$f3->route('GET /','System->load');
$f3->route('GET /api','Api->load');
$f3->route('GET /api/readClass/@class/@type','Api->readClass');
$f3->route('GET /login','Login->load');
$f3->route('GET /logout','Login->logout');
$f3->route('POST /install/valid-license','Install->validLicense');
$f3->route('POST /install/upload-users','Install->uploadUsers');
$f3->route('POST /authenticate','Login->valid');

$f3->run();
